***********************************************************
            ID3v2 Tag Reader/Writer Delphi Unit
***********************************************************


TABLE OF CONTENTS
======================================================= 

  1.) What's New
  2.) Introduction
  3.) Disclaimer
  4.) Interface
  5.) Error Codes
  6.) Known Problems
  7.) Contact Information
  8.) Ordering Information
  9.) Credits


======================================================= 
1. What's New
------------------------------------------------------

Changes in Version 1.05:

- Added USLT and USER frame support
- Fixed setURL function


Version 1.04:

- Fixed loading of empty text frames
- Fixed some problems with Unicode frames

Version 1.03:

- Fixed loading of multi-line comments with getCOMM
- setAsciiText and setURL now automatically remove empty frames
- setTXXX and setWXXX no longer create frames with empty bodies

Version 1.02:

- Fixed typeCount and deleteType functions
- Fixed the loadFromStream & saveToStream resource leaks

Version 1.01:

- Added typeCount and deleteType functions
- Fixed getCOMM function from freezing on empty bodys
- Fixed the "adhereToStandards" option's processing order

Version 1.0:

- SaveToStream function fixed
- Range Check error on tag resizing fixed
- New COMM, TXXX and WXXX frames are created properly
- setCOMM, setTXXX and setWXXX functions now remove frames when the body is empty
  (The also now return smallInts instead of bytes)

beta 4:

- Stream functions fixed
- Added generic encoding type conversion functions
- Added basic UTF-16LE and UTF-8 support
- Added get/setURL functions
- Added COMM, TXXX and WXXX handling functions
- Added auto padding cluster size alignment option
- Miscellaneous corrections
- Example programs updated to support new features

beta 3:

- Full id3v2.4.0 reading/writing support
- Tag loadFromStream and saveToStream functions added
- setFrameData, getFrameData, and clearFrameData functions added
- Added dataLength rule to "adhereToStandard" option
- Added padding size verification (New warning flag, if wrong)
- Size bug fixed for frames with a certain combination of flags set
- Tags with no audio data, that get smaller, are truncated properly
- Tags created with MP3ext now supported (They are actually out of spec)
- Added tag restrictions support
- Miscellaneous corrections
- Example programs updated to support new features
  
beta 2a:

- Creating new tags fixed
- Memory Leak fixed

beta 2:

- Writes id3v2.3.0 tags
- New loading/saving options added
- Functions sync() and unsync() added
- Load function integrated into the tag class
- Load function no longer tries to open files in 'read/write mode'
- "unsync" flag fixed for v2.3.0 frame headers
- Progress bar support added (example in tag dissector)
- Built-in zlib compression support (no external dll's required)
- Functions compress() and uncompress() added
- "data length" flag fixed for v2.3.0 compressed frames
- Extended header, padding and CRC-32 saving support
- Function setAsciiText() added
- Fixed CRC loading problem
- Fixed Tag Dissector's CRC value
- Functions kill() and killTag() added
- Example programs updated to support new features

beta 1:

- Reads id3v2.3.0 tags
- Provides access to all tag/frame header flags and information
- Provides access to the raw frame data of each frame
- Provides formatting functions for the text frames
- Unsynchronization automatically handled


------------------------------------------------------
2. Introduction
------------------------------------------------------

ID3v2 is the next generation of audio tagging. It's
the successor to ID3 (ID3v1 as it's now refered) which
was a very basic tagging scheme that allows basic
textual data to be linked with audio files. The ID3v2
standard surpasses ID3 in every way. No more size
limits, with the ability to add more textual data,
images, and other useful bits of information than you
could ever want.

ID3v2 provides many built-in features that, although
making the format complex, also makes it very flexible
and generally much more useful than it's predecessor.

If you want to add ID3v2 support to your Delphi
programs without having to do a lot of coding, this is
the unit for you. This unit tries to simplify ID3v2
tagging as much as possible, while still leaving the
native flexibility of ID3v2 in tact.

Note: This unit is meant for tag-level modifications,
meaning you (the programmer) must be able to point to
the offset of the beginning of the tag, wherever it
may be, inside the file. 99% of the time, it will be
at the very beginning of the file, but beginning with
version 3 of ID3v2, the tag can actually be located
anywhere in the file. The reason for the tag-level
modifications is that more than one ID3v2 tag can
exist within a single file.


------------------------------------------------------
3. Disclaimer
------------------------------------------------------

Every step has been taken to make sure this unit
adheres to the standard for which it was written, but
as it is currently in beta, some problems may arise.

This unit and the code it contains may be freely used
and distributed in all free and commercial software so
long as proper credit is given.

The source code is available for purchase. (See below)

------------------------------------------------------
4. Interface
------------------------------------------------------

Here is a complete listing of the available functions/
properties and a small description of each. This is
taken straight from the source code (with some
modifications), so please excuse the layout.


Special Frame Types:

   COMM = record
    encoding: byte;
    language: string[3];
    description: string;
    body: string; //full text string
   end;

   USLT = record
    encoding: byte;
    language: string[3];
    description: string;
    body: string; //full text string
   end;

   USER = record
    encoding: byte;
    language: string[3];
    body: string; //full text string
   end;

   TXXX = record
    encoding: byte;
    description: string;
    body: string;
   end;

   WXXX = record
    encoding: byte;
    description: string;
    body: string;
   end;


Tag level:

   Tid3v2tag.Options : record
	  {Load/Save Options}
	  highMinor : boolean; //Attempt to load tag even if Minor version
		//is higher than officially supported (default = true)
	  bypassUnsupported : boolean; //Bypass any ID3v2 features
		//as yet unsupported by this library if possible (default = false)
	  adhereToStandard : boolean; //Adhere to frame rules:
		//1. Removes empty frames
		//2. Forces dataLength flag to true when Compression used
		//(default = true)
	  compLevel : byte; //Compression Level used on frames (0-3)
		//0 = None, 1 = Fastest, 2 = Normal, 3 = Max (default = 2)
        smartPadding : byte; //Padding cluster-size alignment (0-2)
            //0 = None, 1 = Only when necessary, 2 = Always (default = 1)
	  clusterSize : cardinal; //Cluster size used by the smartPadding option 
		//(default = 4096)
	  maxPaddingSize : cardinal; //Maximum allowed padding size (0 = unlimited)
		//(default = 4096) Must be greater than or equal to the clusterSize
	end;

	function loadFromFile(tagFileName:string; tagLoc:Int64):WORD;
{Loads the ID3v2 tag into memory.
 () tagFileName is the name of the file with the id3v2 tag inside
 () tagLoc is the location of the tag within the file
 : Returns error byte (0 if no errors)
}

	function loadFromStream(var tagStream: TMemoryStream; tagLoc:Int64):WORD;
{Loads the ID3v2 tag from the memory stream into the specified tag structure.
 () tagStream is the name of the memory stream with the id3v2 tag inside
 () tagLoc is the location of the tag within the memory stream
 : Returns error byte (0 if no errors)
}

	function saveToFile(tagFileName : string; majorVer : byte;
	 minorVer : byte; const tagLoc : Int64) : WORD;
{Saves the ID3v2 tag into the specified file.
 () tagFileName is the name of the file for the id3v2 tag
 () majorVer/minorVer optional version to save as (if dif from orig)
 () tagLoc saving location of the tag within the file (if dif from orig)
 : Returns error byte (0 if no errors)
}

	function saveToStream(var tagStream: TMemoryStream; majorVer : byte;
	 minorVer : byte; const tagLoc : Int64) : WORD;
{Saves the specified tag into the memory stream as the primary tag.
 () tagStream is the name of the memory stream for the id3v2 tag
 () majorVer/minorVer optional version to save as (if dif from orig)
 () tagLoc saving location of the tag within the memory stream (if dif from orig)
 : Returns error byte (0 if no errors)
}

	function kill: byte;
	//Completely removes the tag from the file

	//Main header flag methods
	function isUnsynced: boolean;
	procedure setUnsync(value : boolean);
	function isExtended: boolean;
	procedure setExtended(value : boolean);
	function isExperimental: boolean;
	procedure setExperimental(value : boolean);
	function isFooter: boolean;
	procedure setFooter(value : boolean);

	//Extended header flag methods
	function isUpdate: boolean;
	procedure setUpdate(value : boolean);
	function isCRC: boolean;
	procedure setCRC(value : boolean);
	function isRestriction: boolean;
	procedure setRestriction(value : boolean);
	procedure setRestrictionValue(value : boolean);

	//Frame processing methods: Single Frames -

	function getAscii(var textStream: TMemoryStream; strPos: cardinal;
	 var strLen: cardinal; textType: byte; var saveString: string):byte;
	//Generic encoding type converter used by the frame formatting functions.
	//Converts UTF-16 (1), UTF-16LE (2), and UTF-8 (3) to Ascii (0).
	//Also supported, is BOM-less UTF-16BE (9) needed for multiple strings in a single frame.
	//Use the special encoding type "9" to force UTF-16BE converting.
	//() textStream is the stream to read the text from.
	//() strPos is the position within the stream to start reading.
	//() strLen is the number of characters to read (0 = read until NULL character)
	//() textType is the text format in the stream:
	//	0 = Ascii, 1 = UTF-16, 2 = UTF-16LE, 3 = UTF-8, 9 = BOM-less UTF-16BE
	//() saveString is where the resulting string is stored.

	function getAsciiText(const frameType: string; var saveString: string): byte;
	function setAsciiText(const frameType: string; const saveString: string): byte;
	//Gets/Sets the text from the specified frame type. Text is loaded/saved in saveString.
	//Works with all text frames that begin with the letter "T" except for the "TXXX" frame.

	function getURL(const frameType: string; var newURL: string): byte;
	function setURL(const frameType: string; const newURL: string): byte;
	//Gets/Sets the URL from the specified frame type. URL is loaded/saved in newURL.
	//Works with all URL frames that begin with the letter "W" except for the "WXXX" frame.

	function getCOMM(out frame: COMM; const description: string; const language: string = 'None'): byte; overload;
      	function getCOMM(out frame: COMM; const index: cardinal): byte; overload;
	function setCOMM(const frame: COMM; const description: string; const language: string= 'None'): shortInt; overload;
	function setCOMM(const frame: COMM; const index: cardinal): shortInt; overload;
	//Gets/Sets the COMM frame by either the index or description and language (optional)

	function getUSLT(out frame: USLT; const description: string; const language: string = 'None'): byte; overload;
      	function getUSLT(out frame: USLT; const index: cardinal): byte; overload;
	function setUSLT(const frame: USLT; const description: string; const language: string= 'None'): shortInt; overload;
	function setUSLT(const frame: USLT; const index: cardinal): shortInt; overload;
	//Gets/Sets the USLT frame by either the index or description and language (optional)

	function getUSER(out frame: USER; const language: string = 'None'): byte; overload;
      	function getUSER(out frame: USER; const index: cardinal): byte; overload;
	function setUSER(const frame: USER; const language: string= 'None'): shortInt; overload;
	function setUSER(const frame: USER; const index: cardinal): shortInt; overload;
	//Gets/Sets the USER frame by either the index or language (optional)

	function getTXXX(out frame: TXXX; const description: string): byte; overload;
	function getTXXX(out frame: TXXX; const index: cardinal): byte; overload;
	function setTXXX(const frame: TXXX; const description: string): shortInt; overload;
	function setTXXX(const frame: TXXX; const index: cardinal): shortInt; overload;
	//Gets/Sets the TXXX frame by either the index or description

	function getWXXX(out frame: WXXX; const description: string): byte; overload;
	function getWXXX(out frame: WXXX; const index: cardinal): byte; overload;
	function setWXXX(const frame: WXXX; const description: string): shortInt; overload;
	function setWXXX(const frame: WXXX; const index: cardinal): shortInt; overload;
	//Gets/Sets the WXXX frame by either the index or description

	function getFrameData(const indexVal : cardinal; var rawFrameData : TStream): byte;
	//Copies the frame data for the specified frame into the rawFrameData stream.
	//Uses TStream.copyFrom function (frame data is copied to the current position in rawFrameData).
	//Note: Make sure you uncompress/decrypt/etc. before using this function, unless you want the
	//compressed/encrypted/etc. data.

	function setFrameData(const indexVal : cardinal; var rawFrameData : TStream; const offset: cardinal = 0;
	const insertData: boolean = false): byte;
	//Copies the specified stream into the frame. The optional 'offset' and 'insert' parameters
	//allow you copy the data to a certain point in the frame, and to insert the data in-between
	//the data before and after the offset instead of over-writing it (default).

	function clearFrameData(const indexVal : cardinal; const offset: cardinal = 0; sizeToClear: cardinal = 0): byte;
	//Clears the frame data. You can delete only portions of the frame data by using the 'offset'
	//and 'sizeToClear' parameters. Specifying a 'sizeToClear' of 0 will delete everything after
	//the offset. Thus when both are 0, all frame data is cleared.

	 //Read-Only properties:
	majorRev : byte;  //Major version of tag
	minorRev : byte;  //Minor version of tag
	tagSetSize : cardinal;  //Size of the tag as set in the header
	extendedHeaderSize : cardinal;  //Size of the extended header
	CRCvalue : DWORD;  //The 32-bit CRC value, loaded from the tag
	tagRestriction : byte;  //Tag restriction flags used in id3v2.4.0 (N/A yet)
	sourceFile : string;  //Last file that had the tag read from or written to
	sourceFileOffset : cardinal;  //Offset of the tag within the source file
	sourceReadOnly : boolean;  //True if the file the tag was loaded from is read-only
	changed : boolean;  //True if tag has been modified (N/A yet)
	validTag : WORD;  //Same as the return value of the save/load functions
	loaded : boolean;  //True when the tag has finished loading
	progress : byte;  //Percentage of progress of tag save/load/kill functions (0-100)
	progressInfo : string;  //Status of current point of load/save

	//Read/Write properties:
	padSize : cardinal;  //The size of padding after the tag


Frame Level:

   TFrameIndex = class

	These will be the flag settings that will be set and stored in the tag when
	you save it:

	//Save settings (flags)
	function isTagAlter(index : cardinal): boolean;
	function isFileAlter(index : cardinal): boolean;
	function isReadOnly(index : cardinal): boolean;
	function isGrouped(index : cardinal): boolean;
	function isCompressed(index : cardinal): boolean;
	function isEncrypted(index : cardinal): boolean;
	function isUnsynced(index : cardinal): boolean;
	function isDataLength(index : cardinal): boolean;

	These are the current flag settings, usefull when still manipulating the
	data, but the save flags over-write these when you save it:

	//Current data (in memory) settings (flags) 
	function isnowTagAlter(index : cardinal): boolean;
	function isnowFileAlter(index : cardinal): boolean;
	function isnowReadOnly(index : cardinal): boolean;
	function isnowGrouped(index : cardinal): boolean;
	function isnowCompressed(index : cardinal): boolean;
	function isnowEncrypted(index : cardinal): boolean;
	function isnowUnsynced(index : cardinal): boolean;
	function isnowDataLength(index : cardinal): boolean;

	{Flag Additions}
	function getDataLength(index : cardinal): cardinal;
	//Gets the true data length of the data in the frame before it was
	//compressed/unsynced. If the frame is not compressed/unsynced, this will be 0.

	function getEncMethod(index : cardinal): byte;
	procedure setEncMethod(index : cardinal; newMethod : byte);
	//Get and set the encryption method. Since encryption is not yet implemented,
	//these functions are rather useless for now.

	function getGroupID(index : cardinal): byte;
	procedure setGroupID(index : cardinal; newID : byte);
	//Get and set the group ID of each frame. Also not yet implemented.

	function getFrameID(index : cardinal): string;
	function setFrameID(index : cardinal; frameType : string): boolean;
	//Get and set the 4-character Frame ID of a frame. (ie. 'TPE1')

	function getLocation(index : cardinal): cardinal;
	//Location (offset) of frame within the tag.

	function getSizeOfHeader(index : cardinal): cardinal;
	//Gets the size of the header.

	function getSize(index : cardinal): cardinal;
	//Gets the size of the frame data.

	function compress(const index : cardinal; const CLevel: byte): integer;
	function decompress(const index : cardinal): integer;
	function unsync(const index : cardinal): integer;
	function sync(const index : cardinal): integer;
	//compress/decompress and unsync/sync the frame data. Note that you cannot
	//compress frame data after it has already been unsynced. You must always
	//compress first, then unsync. (When encryption is added, it will be compress,
	//then encrypt, then unsync)

	function add(frameType : string): cardinal;
	//add a new frame of the specified frame type to the tag. The frame is added to
	//the end of the frame list, so just use the frame count to reference it.

	function delete(index : cardinal): boolean;
	//deletes the specified frame from the tag.

	function deleteType(frameType : string): boolean;
	//deletes all instances of the specified frame type from the tag.
	//returns false if no frames of the specified type are found.

	procedure deleteAll;
	//removes all the frames from the tag.

	function getFrameDataAddr(indexVal : cardinal): Pointer;
	//returns a pointer to the frame's data stream.

      function typeCount(frameType : string): cardinal;
      // returns the number of frames of the specified type in the tag.

	function getCurFlagBytes(indexVal : cardinal; indexByte : byte): byte;
	function getSaveFlagBytes(indexVal : cardinal; indexByte : byte): byte;
	procedure setSaveFlagBytes(indexVal : cardinal; indexByte, value: byte);
	property CurFlagBytes[indexVal: cardinal; indexByte: byte] : byte;
	property SaveFlagBytes[indexVal: cardinal; indexByte: byte] : byte;
	//Use these functions/properties to access the frame's flag bytes. See below for
	//the flag byte layout. Note that this is the layout of id3v2.4.0 frames, but
	//all tag versions are stored internally as id3v2.4.0 tags with this library.

	CurFlagBytes : array[1..2] of byte; {Flags currently set}
	SaveFlagBytes : array[1..2] of byte; {Flags to set when saving}
	{Status Flags %0abc0000 (byte 1)}
	  {a. Tag Alter Preservation}
	  {b. File Alter Preservation}
	  {c. Read Only}
	{Encoding Flags %0h00kmnp (byte 2)}
	  {h. Group Identity}
	  {k. ZLib Compression}
	  {m. Encryption}
	  {n. Unsynchronized frame}
	  {p. Data Length Indicator}

	property Count : cardinal; //The # of frames in the tag



------------------------------------------------------
5. Error Codes
------------------------------------------------------

You can easily learn how to use this unit by taking
a look at the demo projects included. However, some
things aren't covered in the demos, such as error
codes. So here is a list of the error code values for
the available functions:

The four main functions:

Tid3v2tag.loadFromFile()
Tid3v2tag.loadFromStream()
Tid3v2tag.saveToFile()
Tid3v2tag.saveToStream()

all return a WORD containing two 1-byte codes. The
1st byte represents an integer (0-255) and are error
codes if the tag was not properly loaded/saved.

0   = ok
1   = file couldn't be opened
2   = file couldn't be opened for writing
3   = Couldn't read from file
4   = Couldn't write to file
5   = Unspecified I/O Error
8   = Specified tag location past EOF
16  = ID3v2 header not found
17  = ID3v2 MAJOR version not supported
18  = ID3v2 MINOR version not supported
32  = Bad specified tag size
33  = Bad Frame ID found
34  = Tag exceeds size limits
64  = Unknown encryption method
    This library doesn't support:
192 = Encryption
193 = Grouping
194 = Data length could not be calculated because the data is encrypted
    General Errors:
252 = Tag is still in the process of loading
253 = No frames in the tag
254 = Bad ID3v2 tag
255 = Unknown Error Encountered


The 2nd byte is for warning flags. If set, the tag
loaded/saved fine, but some unknown/unsupported
elements were found.

%abcdef00

a = unknown flags set in header
b = unknown flags set in extended header
c = unknown flags set in frame header(s)
d = ID3v2 Minor version higher than latest supported
e = Unsupported ID3v2 feature bypassed
f = Extended header padding size and actual padding size do not match

The functions:

Tid3v2tag.kill()
killTag()

return a single byte error code that corresponds
with the list above, but only some results are
possible:

0   = ok
1   = file couldn't be opened
2   = file couldn't be opened for writing
5   = Unspecified I/O Error
16  = ID3v2 header not found
252 = No tag loaded
254 = Bad ID3v2 tag


The functions:

Tid3v2tag.getAsciiText()
Tid3v2tag.setAsciiText()
Tid3v2tag.getURL()
Tid3v2tag.setURL()
Tid3v2tag.getCOMM()
Tid3v2tag.setCOMM()
Tid3v2tag.getTXXX()
Tid3v2tag.setTXXX()
Tid3v2tag.getWXXX()
Tid3v2tag.setWXXX()

return a single byte error code.

-1  = Body was empty so frame was removed
0   = ok
1   = Frame not found
2   = Empty frame
3   = Bad frame ID
4   = Non-convertable Unicode characters found
5   = Text format not supported
6   = Bad Encoding value
7   = Language type not allowed
8   = Bad frame
9   = Encrypted frame


The functions:

Tid3v2tag.getFrameData()
Tid3v2tag.setFrameData()
Tid3v2tag.clearFrameData()

return a single byte error code.

0   = ok
1   = Index incorrect (Frame not found)
2   = Stream format not supported (TMemoryStream & TFileStream only)
3   = Specified offset extends past end of stream
4   = Encrypted frame
5   = Compressed frame
6   = Unsynced frame

(get only returns 0,1,2)
(clear only returns 0,1,3)
(set can return all)

------------------------------------------------------
6. Known Problems
------------------------------------------------------

Error checking in most of the small functions is
rather thin at the moment, so don't do anything weird.
(eg. Don't click the compress button during saving,
it'll do it... or at least try to do it.)

The progress bar is somewhat jumpy. Do NOT use it for
checking whether the file is finished loading/saving!
Use the Tid3v2tag.loaded property to find that out.

The values of the frame locations for frames loaded
from id3v2.3.0 tags that are unsynchronized, will be
wrong. The values given are less than the real values
by the number of unsynchs between the start of the
frame and the end of the buffer used to load them. So
basically, don't rely on the frame location values in
your programs. There is no problem with id3v2.4.0
tags. This is a problem with the way tags are
currently loaded. ID3v2.3.0 tags are unsynchronized in
the buffer as they are being loaded and thus the
original frame locations are never known. This doesn't
happen with id3v2.4.0 tags because each frame is
individually unsynched, so no unsynching is done
during loading. This will be fixed when I change the
way id3v2.3.0 tags are loaded to match the id3v2.4.0
loading. It'll also speed up loading time since frames
won't be synched until their data is actually
requested. 


------------------------------------------------------
7. Contact Information
------------------------------------------------------

Suggestions, questions, corrections, or comments?

send an e-mail to: lib@audioxl.com

If you've written a program that makes use of this
library, let me know, and if you like, I'll add a
link to your website.


------------------------------------------------------
8. Ordering Information
------------------------------------------------------

I've had quite a few requests from people wanting to
purchase the source code for the ID3v2 Delphi Library,
so I have decided to make it available.

For those who are serious about obtaining the source
code, the current source is available for $149.
Registrants will, of course, receive future source
updates for free.

You can order it here:
https://secure.element5.com/shareit/checkout.html?productid=145991&language=English

Or you can go to http://www.shareit.com and enter
the program ID number 145991 in the search window at
the bottom left of the screen.

We also accept orders via email at: 
service@shareit.com

You can place your order by phone:

Phone: +49-221-31088-20
Fax: +49-221-31088-29

US and Canadian customers may also order by calling
toll-free 1-800-903-4152


(For the rest of you developers, don't worry, the
compiled versions will always remain free.)


------------------------------------------------------
9. Credits
------------------------------------------------------

All programming done by James Webb

Thanks to:

Martin Nilsson
Lasse Karlsen
Anders Thomsen
Andrew Connell
the beta testers
everyone who's sent me a bug report
and all those nice people on the id3.org mailing list.


Copyright (c) 1998-2003 audioxl.com
